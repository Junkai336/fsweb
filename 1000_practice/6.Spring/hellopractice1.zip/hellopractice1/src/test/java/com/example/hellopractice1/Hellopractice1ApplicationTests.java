package com.example.hellopractice1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hellopractice1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
