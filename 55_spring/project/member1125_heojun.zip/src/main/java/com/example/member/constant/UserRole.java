package com.example.member.constant;

public enum UserRole {

    USER, ADMIN

}
