package jpabook.jpashob;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpashobApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpashobApplication.class, args);
	}

}
